import React from 'react'
import Navbar from 'react-bootstrap/Navbar';
import Container from 'react-bootstrap/Container';
import "./Header.css";

const Header = () => {
  return (
    <div>
    <Navbar className="bg-body-tertiary">
      <Container>
        <a href="/Mypage" className='mynav' style={{color:"black",fontSize:"30px"}}>Welcome To Travel Chatbot</a>
        <Navbar.Toggle />
        <Navbar.Collapse className="justify-content-end">
          <Navbar.Text>
            <a href="/Login">Login</a>
          </Navbar.Text>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </div>
  )
}

export default Header