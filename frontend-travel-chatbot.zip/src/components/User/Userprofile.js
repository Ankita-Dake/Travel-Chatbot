import React from 'react'
import Sidebar from '../Home/Sidebar'
import Sidebar from '../Home/Sidebar'

const Userprofile = () => {
  return (
    <div>Userprofile
        <Sidebar/>
    </div>
  )
}

export default Userprofile