import "./Gethistory.css";
import { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from "react-router-dom";
import Table from "react-bootstrap/Table";
import Container from "react-bootstrap/Container";

function GetAllHisotry() {
    // const { tag_id } = useParams();
    // console.log("id:",tag_id);

    const [historyDetails, setHistoryDetails] = useState([]);

    let token = localStorage.getItem("user-token");
    
    console.log("Token --", token);

    //  Code to get the project details
    useEffect(()=>{
   axios({
        //baseURL: `http://localhost:8000/histroy/${15}`,
        baseURL: `http://127.0.0.1:8000/users_current/${token}`,
        method: "GET",
      })
        .then((res) => {
          if (res.status === 200) {
            console.log("Get Tag by ID res.data:", res.data);
            setHistoryDetails([res.data]);
          }
        })
        .catch((error) => {
          console.log("ERROR", error);
          // alert("Error in Tag by ID Data Data");
        });


}, []);




 console.log("deatils", historyDetails);
// console.log("deatils", historyDetails.tag_id);


  return (
   <Container>
          <Table striped bordered hover variant="light">

            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>User Type</th>
                <th>Phone Number</th>
              </tr>
            </thead>

            <tbody>

                { historyDetails.map((x, index) =>{
                    return (
                        <tr key={index}>
                        <td>{x.name}</td>
                        <td>{x.email}</td>
                        <td>{x.user_type}</td>
                        <td>{x.phone_number}</td>
                        {/* { <td>
                          <Link to={`/manager/projectWeeklyReportOverview/${x.id}`}><FaEye style={{ fontSize: "20px", color:'black' }} /></Link> 
                        </td> } */}
                      </tr>   
                    )
                }
          )}

            </tbody>
          </Table>
        </Container>
  )
}

export default GetAllHisotry