import axios from "axios";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Container from "react-bootstrap/Container";
import React, { useEffect,useState } from "react";

const Chatresponse = () => {
  const [currentdata, setCurrentdata] = useState([]);
  const [chatdata,setChatdata] = useState();
  const [getBotResponse, setGetBotResponse] = useState();

  let token = localStorage.getItem("user-token");
  
  console.log("Token --", token);

  //  Code to get the project details
  useEffect(()=>{
 axios({
      //baseURL: `http://localhost:8000/histroy/${15}`,
      baseURL: `http://127.0.0.1:8000/users_current/${token}`,
      method: "GET",
    })
      .then((res) => {
        if (res.status === 200) {
          console.log("Get Tag by ID res.data:", res.data);
          setCurrentdata([res.data]);
        }
      })
      .catch((error) => {
        console.log("ERROR", error);
        // alert("Error in Tag by ID Data Data");
      });


}, []);

function handleSubmit(event) {
  event.preventDefault();
    // console.log("getBotResponse:  ",getBotResponse);
    // console.log('password:', password);
      axios({
           baseURL: `http://127.0.0.1:8000/chat/${token}`,
           method: "POST",
           data: {
           user_query: chatdata
          },
         })
           .then((res) => {
             if (res.status === 200) {
              console.log("result.data:",res.data);;
              setGetBotResponse(res.data);
             }
           })
           .catch((error) => {
             console.log("ERROR", error);
             //alert("Error in Tag by ID Data Data");
           });
     
  
}

 console.log('chat response:',chatdata);
 console.log('getBotResponse:',getBotResponse);

  return (
      <div className="Register">
      <Container className="heading">
        <h2></h2>
      </Container>

      <Container className="form">
        <Form onSubmit={handleSubmit}>
          
          <Container>
            <Form.Group size="lg" controlId="user query">
              <Form.Label>User query</Form.Label>
              <Form.Control
                autoFocus
                type="text"
                name="chatdata"
                value={chatdata}
                onChange={(e) => setChatdata(e.target.value)}
              />
            </Form.Group>
            <div className="d-grid gap-1 mt-4">
            <Button style={{backgroundColor:"#A2678A"}} 
                    size="lg"
                    type="submit"
                    className="mb-3">
                  submit
            </Button>
            </div>
            </Container>
            </Form>
            </Container>
    </div>
  )
}

export default Chatresponse