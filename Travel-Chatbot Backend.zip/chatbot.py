# import nltk
# import re
# import random
# import string
# from nltk.chat.util import Chat, reflections
# from string import punctuation
# from app.routes.web_routes import scrape_web

# # Download stopwords from nltk
# nltk.download('punkt')
# nltk.download('stopwords')
# stop_words = set(nltk.corpus.stopwords.words('english'))

# def sentence_tokenizer(data):
#    # Function for Sentence Tokenization
#    return nltk.sent_tokenize(data.lower())

# def word_tokenizer(data):
#    # Function for Word Tokenization
#    return nltk.word_tokenize(data.lower())

# def remove_noise(word_tokens):
#    # Function to remove stop words and punctuation
#    cleaned_tokens = []
#    for token in word_tokens:
#       if token not in stop_words and token not in punctuation:
#          cleaned_tokens.append(token)
#    return cleaned_tokens

# # Define the Patterns and Responses
# patterns = [
#    ("What are the hotel name",[scrape_web])
# ]
# # with open("posts",'r') as file:
# #    orginal_content = file.read()

# # Function to generate response for the user input
# def generate_response(user_input):
#    # Append User Input to chat history
# #    conversation_history.append(user_input)
#    # Generate Random response
# #    response = random.choice(responses)
#    chat = Chat(patterns, reflections)
#    response = chat.respond(user_input)
#    return response

# # Main loop of chatbot
# # conversation_history = []
# # responses = [response for response in orginal_content]
# # while True:
# def chat_bot_response(user_input):
#    # User Input
# #    user_input = input("You: ")
#    # End the Loop if the User Says Bye or Goodbye
#    if user_input.lower() in ['bye', 'goodbye']:
#     #   print('Chatbot: Goodbye!')
#       return 'Chatbot: Goodbye!'
#    # Tokenize the User Input
#    user_input_tokenized = word_tokenizer(user_input)
#    # Remove Stop Words
#    user_input_nostops = remove_noise(user_input_tokenized)
#    # Process Query and Generate Response
#    chatbot_response = generate_response(user_input)
#    # Print Response
#    print('Chatbot:', chatbot_response)
#    return chatbot_response
   
   
   
   
   
   
   
   
# ====================================================================
import nltk
import random
import string
import warnings
from fastapi import APIRouter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import os

warnings.filterwarnings('ignore')

chat_routes = APIRouter() 

path = r"D:\Travel Chatbot-Ankita Dake\Travel_ChatBot_Project\posts.txt"
assert os.path.isfile(path)
# with open(path, "r") as f:
f = open(path,'r',errors='ignore')
raw_data = f.read()
raw = raw_data.lower()

sent_tokens = nltk.sent_tokenize(raw)
word_tokens = nltk.word_tokenize(raw)

# print(sent_tokens)
# # print(word_tokens) 

# Pre processing
lemmer = nltk.stem.WordNetLemmatizer()

def lemtoken(tokens):
    return [lemmer.lemmatize(token) for token in tokens]

remove_punct_dict = dict((ord(punct), None) for punct in string.punctuation)

def len_normalize(text):
    return lemtoken(nltk.word_tokenize(text.lower().translate(remove_punct_dict)))

# greeting 
greeting_input = ("hello",'hi','hey')
greeting_response = ['hi','hey','hello']

def greeting(sentense):
    for word in sentense.split():
        if word.lower() in greeting_input:
            return random.choice(greeting_response)
        
# vectorizer
def response(user_response):
    my_response=''
    final_str = ""
    sent_tokens.append(user_response)
    TfidfVec = TfidfVectorizer(tokenizer=len_normalize, stop_words='english')
    tfidf = TfidfVec.fit_transform(sent_tokens)
    vals = cosine_similarity(tfidf[-1], tfidf)
    idx=vals.argsort()[0][-2]
    flat = vals.flatten()
    flat.sort()
    req_tfidf = flat[-2]
    if(req_tfidf==0):
        my_response=my_response+"I am sorry! I don't understand you"
        return my_response
    else:
        my_response = my_response+sent_tokens[idx]
        # for letter in my_response:
        #     if letter != "\n":
        #         final_str = final_str + letter
        #     else:
        #          final_str = final_str + " "
        return my_response
    
def mainresponse(user_response):
    flag=True
    while(flag==True):
        user_response=user_response.lower()
        if(user_response!='bye'):
            if(user_response=='thanks' or user_response=='thank you' ):
                flag=False
                result=("Bot Response: You are welcome..")
            else:
                if(greeting(user_response)!=None):
                   result=(greeting(user_response))
                else:
                    result=response(user_response)
                    sent_tokens.remove(user_response)
            return result
        else:
            flag=False
            print("Bot Response: Bye! take care..")
