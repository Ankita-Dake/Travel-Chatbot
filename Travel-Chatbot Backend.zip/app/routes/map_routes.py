from fastapi import FastAPI,HTTPException,APIRouter
import requests

map_routes = APIRouter()

mappls_key = "bc46d225ce9e38f66c9bc1105b4ea0b6"

@map_routes.get("/distance")
async def calculate_distance(origin:str,destination:str):
    url = f"https://www.mapquestapi.com/directions/v2/routes?key={mappls_key}&from={origin}&to={destination}"
    try:
        response =requests.get(url)
        response.raise_for_status()
        data = response.json()

        distance = data['route']['distance']
        return {'distance':distance}

    except requests.RequestException as e:
        raise HTTPException(status_code=500,detail=f'error comunication with mappls api key:{str(e)}')
    except KeyError:
        raise HTTPException(status_code=400,detail="Invalid") 